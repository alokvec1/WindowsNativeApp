﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace WindowsNativeApp
{
    public class Program
    {
        public static bool IsConsoleLogEnable = Convert.ToBoolean(ConfigurationManager.AppSettings["IsConsoleLog"]);
        public static StringBuilder logger = new StringBuilder();
        public httpVerb httpMethod { get; set; }
        static void Main(string[] args)
        {


            SystemCompleteInfo systemCompleteInfo = new SystemCompleteInfo();

            //Get system information
            SystemInformation systemInfo = new SystemInformation();
            systemCompleteInfo.systemInformation = systemInfo.GetSystemInformation();

            //Get Memory CPU Usage
            MemoryCpuUsage memoryCpuUsage = new MemoryCpuUsage();
            systemCompleteInfo.memory_CPUUsage = memoryCpuUsage.GetMemoryCpuUsage();

            //Get Disk Usage
            DiskUsage diskUsage = new DiskUsage();
            systemCompleteInfo.diskUsage = diskUsage.GetDiskUsage();
            JsonSerializer serializer = new JsonSerializer();

            string dateAndTime = DateTime.Now.ToShortDateString() + "-" + DateTime.Now.ToShortTimeString();
            dateAndTime = dateAndTime.Replace('/', '-');
            dateAndTime = dateAndTime.Replace(':', '-');

            //string filename = String.Format("SystemInfo-{0}.json" , DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss"));
            string filename = String.Format("SystemInfo.json");
            string path = AppDomain.CurrentDomain.BaseDirectory + filename;
            var tw = new StreamWriter(path, true);

            //var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://52.191.4.233:80/api/v1/machinedetails");
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://52.191.4.233:80/api/v1/machinedetails");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = new JavaScriptSerializer().Serialize(systemCompleteInfo);
                streamWriter.Write(json);
                streamWriter.Flush();
                streamWriter.Close();
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
            }
            WriteToConsole(logger.ToString());
        }

        public static  void PostData()
        {
            string filename = String.Format("SystemInfo.json");
            string path = AppDomain.CurrentDomain.BaseDirectory + filename;
            //var client = new RestClient(ConfigurationManager.AppSettings["address"]);
            var client = new RestClient("http://192.168.0.189:8080/api/v1/machinedetails");
            var request = new RestRequest("machinedetails", Method.Post);
            request.AddFile(filename, path);
            request.AddHeader("Content-Type" , "application/json;charset=utf-8");
            var response = client.Execute(request);
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                string apiResponse = response.Content;
                SystemCompleteInfo result = JsonConvert.DeserializeObject<SystemCompleteInfo>(apiResponse);
            }

            //DebugOutput(strResponse);
        }
        private  static void DebugOutput(string strdebugText)
        {
            try
            {
                System.Diagnostics.Debug.Write(strdebugText + Environment.NewLine);
            }
            catch(Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message.ToString() + Environment.NewLine);
            }
            
        }

        static async Task ConsumeAPI()
        {
            
            string filename = String.Format("SystemInfo.json");
            string path = AppDomain.CurrentDomain.BaseDirectory + filename;
            var json = JsonConvert.SerializeObject(filename);
            var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            var client = new HttpClient();
            //string encodeUrl = Uri.EscapeDataString("https://jsonplaceholder.typicode.com/posts/1/comments");
            // client.BaseAddress = new Uri("http://52.191.4.233:80/api/v1/machinedetails");
            
            client.BaseAddress = new Uri("http://192.168.0.189:8080/api/v1/machinedetails");
            var request = new RestRequest("machinedetails", Method.Post);
            request.AddFile(filename, path);
            request.AddHeader("Content-Type", "application/json;charset=utf-8");

            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            var response = await client.PostAsync(client.BaseAddress, stringContent);
            //var response = await client.GetAsync(client.BaseAddress);
            //HttpResponseMessage response = await client.PostAsync("client.BaseAddress", machinedetails);
            if (response.IsSuccessStatusCode)
            {
                dynamic result = await response.Content.ReadAsStringAsync();
                SystemCompleteInfo systemCompleteInfo = JsonConvert.DeserializeObject<SystemCompleteInfo>(result);

                //foreach(var item in systemCompleteInfo.SystemInformation)
                //{
                //    Console.WriteLine("{0}\t${1}\t${2}" , item);
                //}
            }
        }
        public static void WriteToConsole(string message)
        {
            if(message == null)
            {
                throw new ArgumentNullException();
            }
            if(IsConsoleLogEnable)
            {
                Console.WriteLine("[" + DateTime.Now.ToString() + "]" + message);
            }
        }
        static public string Encode(string toEncode)
        {
            byte[] toencodeAsByte = System.Text.ASCIIEncoding.ASCII.GetBytes(toEncode);
            string returnValue = System.Convert.ToBase64String(toencodeAsByte);
            return returnValue;
        }
        public enum httpVerb
        {
            GET,
            POST
        }
    }
}
