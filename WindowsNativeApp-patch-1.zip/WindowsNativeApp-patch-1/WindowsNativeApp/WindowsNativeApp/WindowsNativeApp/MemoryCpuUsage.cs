﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    internal class MemoryCpuUsageEntity
    {
        public string memoryUsage { get; set; }
        public string swapUsage { get; set; }
        public string cpuUsage { get; set; }
    }
    internal class MemoryCpuUsage
    {
        public MemoryCpuUsageEntity GetMemoryCpuUsage()
        {
            MemoryCpuUsageEntity entity = new MemoryCpuUsageEntity();
            //entity.MemoryUsage = GetUsedRAM();
            entity.swapUsage = "";
            entity.cpuUsage = GetUsedCPU();
            return entity;
        }
        public static string GetUsedRAM()
        {
            PerformanceCounter RAMCounter;
            RAMCounter = new PerformanceCounter();
            RAMCounter.CategoryName = "Memory";
            RAMCounter.CounterName = " % Committed Bytes In Use";
            NumberFormatInfo nfi = new CultureInfo("en-US", false).NumberFormat;
            return String.Format("{0:0.00}" + "%", RAMCounter.NextValue());
        }

        public static string GetUsedCPU()
        {
            PerformanceCounter CPUCounter;
            CPUCounter = new PerformanceCounter();
            CPUCounter.CategoryName = "Processor";
            CPUCounter.CounterName = "% Processor Time";
            CPUCounter.InstanceName = "_Total";
            CPUCounter.NextValue();
            System.Threading.Thread.Sleep(1000);
            return String.Format("{0:0.00}" + "%" , CPUCounter.NextValue());
        }
    }
}
