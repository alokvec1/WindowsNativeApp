﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Net;
//using System.Text;
//using System.Threading.Tasks;

//namespace WindowsNativeApp
//{
//    public class RestClient
//    {
//        public string endPoint { get; set; }
//        public httpVerb httpMethod { get; set; }
//        public string postJSON { get; set; }
//        public RestClient()
//        {
//            endPoint = string.Empty;
//            httpMethod = httpVerb.POST;
//        }

//        public string MakeRequest()
//        {
//            string strResponse = string.Empty;
//            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endPoint);
//            request.Method = httpMethod.ToString();
//            if (request.Method == "POST" && postJSON != string.Empty)
//            {
//                request.ContentType = "application/json";
//                using (StreamWriter swjsonPayload = new StreamWriter(request.GetRequestStream()))
//                {
//                    swjsonPayload.Write(postJSON);
//                    swjsonPayload.Close();
//                }
//            }
//            HttpWebResponse httpWebResponse = null;
//            try
//            {
//                httpWebResponse = (HttpWebResponse)request.GetResponse();
//                using (Stream responseStream = httpWebResponse.GetResponseStream())
//                {
//                    if (responseStream != null)
//                    {
//                        using (StreamReader reader = new StreamReader(responseStream))
//                        {
//                            strResponse = reader.ReadToEnd();
//                        }
//                    }
//                }
//            }
//            catch (Exception ex)
//            {
//                strResponse = "{ \"errorMessage\" : [\"" + ex.Message.ToString() + "\"] , \"errors\" :{}}";
//            }
//            return strResponse;
//        }


//    }
//    public enum httpVerb
//    {
//        GET,
//        POST
//    }
//}
