﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    internal class FileSystemEntity
    {
        public string FileSystem { get; set; }
        public string Size { get; set; }
        public string Used { get; set; }
        public string Avail { get; set; }
        public string Use { get; set; }
        public string MountedOn { get; set; }
    }
    internal class FileSystems
    {
        public List<FileSystemEntity> GetFileSystems()
        {
            List<FileSystemEntity> entities = new List<FileSystemEntity>();
            var drives = DriveInfo.GetDrives().Where(d => d.DriveType == DriveType.Fixed).Where(d => d.IsReady).ToArray();

            foreach (var drive in drives)
            {
                FileSystemEntity entity = new FileSystemEntity();
                entity.FileSystem = drive.DriveFormat;

                long size = (((drive.TotalSize / 1024) / 1024 )/ 1024);
                entity.Size = size.ToString() + "GB";

                long avail = (((drive.AvailableFreeSpace / 1024) / 1024) / 1024);
                entity.Avail = size.ToString() + "GB";

                entity.Used = (size - avail).ToString() + "GB";

                entity.Use = "";
                entity.MountedOn = drive.DriveType.ToString();
                entities.Add(entity);
            }

            return entities;
        }

    }

}
