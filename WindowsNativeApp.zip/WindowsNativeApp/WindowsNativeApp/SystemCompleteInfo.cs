﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    internal class SystemCompleteInfo
    {
        public SystemInformationEntity SystemInformation;
        public MemoryCpuUsageEntity MemoryCpuUsage;
        public DiskUsageEntity DiskUsage;

    }
}
