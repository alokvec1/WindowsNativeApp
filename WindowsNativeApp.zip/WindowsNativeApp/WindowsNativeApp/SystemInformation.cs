﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    public class SystemInformation
    {
        public SystemInformationEntity GetSystemInformation()
        {
            SystemInformationEntity entity = new SystemInformationEntity();
            entity.HostName = Environment.MachineName;
            long tickCountMs = Environment.TickCount;
            var uptime = TimeSpan.FromMilliseconds(tickCountMs);
            entity.UpTime = uptime.ToString();
            //Get computer system details
            SelectQuery query = new SelectQuery(@"Select * from Win32_ComputerSystem");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);

            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if(sp.Name == "Manufacturer")
                    {
                        entity.Manufacturer = sp.Value.ToString();
                    }

                    if (sp.Name == "UserName")
                    {
                        entity.ActiveUser = sp.Value.ToString();
                    }
                    if (sp.Name == "Model")
                    {
                        entity.MachineType = sp.Value.ToString();
                    }
                    if (sp.Name == "SystemType")
                    {
                        entity.SystemDetails = sp.Value.ToString();
                    }
                }
            }

            //Get OS Details
            query = new SelectQuery(@"Select * from Win32_OperatingSystem");
            searcher = new ManagementObjectSearcher(query);
            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if (sp.Name == "Name")
                    {
                        entity.OperatingSystem = sp.Value.ToString();
                    }

                    if (sp.Name == "Version")
                    {
                        entity.Version = sp.Value.ToString();
                    }
                    if (sp.Name == "SerialNumber")
                    {
                        entity.SerialNumber = sp.Value.ToString();
                    }
                   
                }
            }
            //Get Processor Details
            query = new SelectQuery(@"Select * from Win32_Processor");
            searcher = new ManagementObjectSearcher(query);
            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if (sp.Name == "Name")
                    {
                        entity.ProcessorName = sp.Value.ToString();
                    }

                }
            }
            entity.Architecture = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE");

            //Get Physical Memory Details
            query = new SelectQuery(@"Select * from Win32_PhysicalMemory");
            searcher = new ManagementObjectSearcher(query);
            Int64 ramAvailable = 0;
            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if (sp.Name == "Capacity")
                    {
                        string mem = sp.Value.ToString();
                        Int64 ramGB = 0;
                        Int64.TryParse(mem , out ramAvailable);
                        ramGB = (((ramAvailable/1024)/1024)/1024);
                        break;
                    }

                }
            }
            entity.SystemMainIp = GetLocalIPAddress();

            Process proc = Process.GetCurrentProcess();
            float memoryUsage = 100 * (ramAvailable - proc.PrivateMemorySize64) / ramAvailable;
            entity.UsageRam = memoryUsage.ToString() + "%";
            entity.ProductName = "";
            entity.Kernel = "";
            //Get Oracle DB Instance
            //query = new SelectQuery(@"Select * from V$ACTIVE_INSTANCES");
            //searcher = new ManagementObjectSearcher(query);
            //foreach (ManagementObject mo in searcher.Get())
            //{
            //    PropertyDataCollection searcherProperties = mo.Properties;
            //    foreach (PropertyData sp in searcherProperties)
            //    {
            //        if (sp.Name == "Instance")
            //        {
            //            entity.OracleDbInstance = sp.Value.ToString();
            //            break;
            //        }

            //    }
            //}

            return entity;
        }

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if(ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system");
        }
    }

    public class SystemInformationEntity
    {
        public string HostName { get; set; }
        public string UpTime { get; set; }

        public string Manufacturer { get; set; }
        public string ProductName { get; set; }
        public string Version { get; set; }
        public string SerialNumber { get; set; }
        public string MachineType { get; set; }
        public string SystemDetails { get; set; }
        public string AvailableRam { get; set; }
        public string UsageRam { get; set; }
        public string OperatingSystem { get; set; }
        public string Kernel { get; set; }
        public string Architecture { get; set; }
        public string ProcessorName { get; set; }
        public string ActiveUser { get; set; }
        public string SystemMainIp { get; set; }
        public string OracleDbInstance { get; set; }
        public string PackageUpdate { get; set; }

        public string wwnDetails { get; set; }
    }

}
