﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    internal class FileSystemEntity
    {
        public string FileSystem { get; set; }
        public string Size { get; set; }
        public string Used { get; set; }
        public string Avail { get; set; }
        public string Use { get; set; }
        public string MountedOn { get; set; }
    }
    internal class FileSystems
    {
        public void GetFileSystems(List<DiskUsageEntity> diskUsageList)
        {
            var drives = DriveInfo.GetDrives().Where(d => d.DriveType == DriveType.Fixed).Where(d => d.IsReady).ToArray();

            foreach (var drive in drives)
            {
                DiskUsageEntity entity = new DiskUsageEntity();
                entity.filesystem = drive.DriveFormat;

                long size = (((drive.TotalSize / 1024) / 1024) / 1024);
                entity.size = size.ToString() + "GB";

                long avail = (((drive.AvailableFreeSpace / 1024) / 1024) / 1024);
                entity.avail = size.ToString() + "GB";

                entity.used = (size - avail).ToString() + "GB";

                entity.use = "";
                entity.mountedOn = drive.DriveType.ToString();
                diskUsageList.Add(entity);
            }
        }

    }

}
