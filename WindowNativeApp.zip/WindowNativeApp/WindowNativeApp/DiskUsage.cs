﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    internal class DiskUsageEntity
    {
        public List<FileSystemEntity> fileSystems;

        public string usage { get; set; }
        public string filesystem { get; set; }
        public string size { get; set; }
        public string used { get; set; }
        public string avail { get; set; }
        public string use { get; set; }
        public string mountedOn { get; set; }
    }
    internal class DiskUsage
    {
        
        public List<DiskUsageEntity> GetDiskUsage()
        {
            List<DiskUsageEntity> diskUsageList = new List<DiskUsageEntity>();
            DiskUsageEntity entity = new DiskUsageEntity();
            entity.usage = GetUsedDisk();
            diskUsageList.Add(entity);
            new FileSystems().GetFileSystems(diskUsageList);
            return diskUsageList;
        }

        public static string GetUsedDisk()
        {
            double TotalDiskSize = 0;
            double AvailableDiskSize = 0;
            double UsedDiskSizePercent = 0;
            double UsedDiskSize = 0;
            DriveInfo[] drives = DriveInfo.GetDrives();

            foreach (DriveInfo drive in drives)
            {
                if(drive.IsReady)
                {
                    TotalDiskSize += drive.TotalSize;
                    AvailableDiskSize += drive.AvailableFreeSpace;
                }
            }

            UsedDiskSize = TotalDiskSize - AvailableDiskSize;
            UsedDiskSizePercent = (UsedDiskSize / TotalDiskSize) * 100;

            return String.Format("{0:0.00}" + "%", UsedDiskSizePercent);
        }
    }
}
